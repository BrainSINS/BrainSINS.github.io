<?php
/*
* The MIT License (MIT)
*
* Copyright (c) 2014 Social Gaming Platform SRL
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software && associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, && to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice && this permission notice shall be included in all
* copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE && NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*/

class BrainSins extends Module {

	public function __construct()
	{
		$this->name = 'brainsins';
		$this->tab = 'advertising_marketing';
		$this->version = '2.05';
		$this->author = 'BrainSINS';
		$this->module_key = '906d257d3b5f5ed569aff512474c9369';

		$this->displayName = $this->l('BrainSINS');
		$this->description = $this->l('BrainSINS, 360º eCommerce Personalization');

		$this->api_url = 'http://durotar.api.brainsins.com/RecSinsAPI/api/';

		parent::__construct();

		if (!Configuration::get('BRAINSINS_USERS_MAIL'))
			$this->warning = $this->l('Please define users eligible for sending mail');

		if (!Configuration::get('BRAINSINS_KEY'))
			$this->warning = $this->l('You have to define the brainSINS key');

		if (!function_exists('curl_init'))
			$this->warning = $this->l("Your server doesn't have cURL extension. Module won't work properly");

		/* Backward compatibility */
		if (version_compare(_PS_VERSION_, '1.5', '<'))
			require(_PS_MODULE_DIR_.$this->name.'/backward_compatibility/backward.php');
	}

	public function install()
	{
		parent::install();

		if (!$this->registerHook('footer') ||
			!$this->registerHook('orderConfirmation') ||
			!$this->registerHook('paymentConfirm') ||
			!$this->registerHook('cart') ||
			!$this->registerHook('top') ||
			!$this->registerHook('leftColumn') ||
			!$this->registerHook('rightColumn') ||
			!$this->registerHook('extraLeft') ||
			!$this->registerHook('productActions') ||
			!$this->registerHook('productOutOfStock') ||
			!$this->registerHook('extraRight') ||
			!$this->registerHook('productFooter') ||
			!$this->registerHook('shoppingCart') ||
			!$this->registerHook('shoppingCartExtra') ||
			!$this->registerHook('paymentTop') ||
			!$this->registerHook('authentication') ||
			!Configuration::updateValue('BRAINSINS_KEY', '') ||
			!Configuration::updateValue('BRAINSINS_USERS_MAIL', '') ||
			!Configuration::updateValue('BRAINSINS_ENABLED', '0') ||
			!Configuration::updateValue('BRAINSINS_DEBUG', '0') ||
			!Configuration::updateValue('BRAINSINS_HOOKS_LOCATIONS', '')
		)
			return false;

		return true;
	}

	public function uninstall()
	{
		if (!parent::uninstall()
			|| !Configuration::deleteByName('BRAINSINS_KEY')
			|| !Configuration::deleteByName('BRAINSINS_USERS_MAIL')
			|| !Configuration::deleteByName('BRAINSINS_ENABLED')
			|| !Configuration::deleteByName('BRAINSINS_DEBUG')
			|| !Configuration::deleteByName('BRAINSINS_HOOKS_LOCATIONS')
		)
			return false;

		return true;
	}

	public function checkBSKey($bskey)
	{
		$pattern = '/^BS-\d{10}-\d+$/';
		if (preg_match($pattern, $bskey))
			return true;

		return false;
	}

	public function getContent()
	{
		$this->_errors = array();
		$this->_success = false;

		if (Tools::isSubmit('saveConfig'))
		{
			Configuration::updateValue('BRAINSINS_ENABLED', (int)Tools::getValue('enabled'));
			Configuration::updateValue('BRAINSINS_DEBUG', (int)Tools::getValue('debug'));

			$bskey = Tools::getValue('bskey');
			if (!isset($bskey))
				$this->_errors[] = $this->l('BrainSINS Key is required');
			elseif (!$this->checkBSKey($bskey))
				$this->_errors[] = $this->l('BrainSINS Key incorrect. It must have the following format: BS-0123456789-1');
			elseif ($bskey != Configuration::get('BRAINSINS_KEY'))
			{
				Configuration::updateValue('BRAINSINS_KEY', $bskey);
				Configuration::updateValue('BRAINSINS_HOOKS_LOCATIONS', '');
			}

			$users_mail = Tools::getValue('users_mail');
			if (!isset($users_mail))
				$this->_errors[] = $this->l('You must define which users would you like to send mails.');
			else
				Configuration::updateValue('BRAINSINS_USERS_MAIL', $users_mail);

			if (!count($this->_errors))
				$this->_success = true;

			$this->context->smarty->assign('tab', '1');
		}
		elseif (Tools::isSubmit('saveRecommenders'))
		{
			//Save hooks locations
			$out = $sep = '';
			$hooksLocations = Tools::getValue('hooksLocation');
			if (isset($hooksLocations) && $hooksLocations != '')
			{
				foreach ($hooksLocations as $key => $value)
				{
					$out .= $sep.$key.':'.implode(':', $value);
					$sep = '|';
				}
			}

			$newHookLocations = Tools::getValue('newHookLocation');
			if (isset($newHookLocations) && $newHookLocations != '')
			{
				foreach ($newHookLocations as $newHookLocation)
				{
					if ($newHookLocation["'id_recommender'"] != '')
						$out .= $sep.implode(':', $newHookLocation);
				}
			}

			Configuration::updateValue('BRAINSINS_HOOKS_LOCATIONS', $out);
			$this->_success = true;
			$this->context->smarty->assign('tab', '2');
		}
		elseif (Tools::isSubmit('deleteRecommenders'))
		{
			$out = $sep = '';

			if (Configuration::get('BRAINSINS_HOOKS_LOCATIONS'))
			{
				foreach (explode('|', Configuration::get('BRAINSINS_HOOKS_LOCATIONS')) as $hook)
				{
					list($recommender_id, $hook_id, $custom_location, $page_type) = explode(':', $hook);
					if (Tools::getValue('deleteRecommenderId') != $recommender_id)
					{
						$out .= $sep.$recommender_id.':'.$hook_id.':'.$custom_location.':'.$page_type;
						$sep = '|';
					}
				}
			}

			Configuration::updateValue('BRAINSINS_HOOKS_LOCATIONS', $out);
			$this->_success = true;
			$this->context->smarty->assign('tab', '2');
		}

		$response = @Tools::file_get_contents($this->api_url.'recommender/retrieve.xml?token='.Configuration::get('BRAINSINS_KEY'));

		if ($response !== false)
		{
			$xmlData = simplexml_load_string($response);
			$jsonData = Tools::jsonDecode(Tools::jsonEncode((array)$xmlData), true);

			//Groups recommenders by place
			$recommenders = array();
			foreach ($jsonData['recommenders']['recommender'] as $recommender)
				$recommenders[$recommender['place']][] = $recommender;
		}
		else
			$error = true;

		//Hooks
		$hooks = array(
			'Home' => array(
				array(	'id' => 1,
						'name' => $this->l('Top')),
				array(	'id' =>	2,
						'name' => $this->l('Left column')),
				array(	'id' =>	3,
						'name' => $this->l('Right column')),
				array(	'id' =>	4,
						'name' => $this->l('Footer'))
				),
			'Producto' => array(
				array(	'id' => 14,
						'name' => $this->l('Top')),
				array(	'id' =>	15,
						'name' => $this->l('Left column')),
				array(	'id' =>	16,
						'name' => $this->l('Right column')),
				array(	'id' =>	17,
						'name' => $this->l('Footer')),
				array(	'id' => 5,
						'name' => $this->l('Extra left')),
				array(	'id' =>	6,
						'name' => $this->l('Product actions')),
				array(	'id' =>	7,
						'name' => $this->l('Product Out of Stock')),
				array(	'id' =>	8,
						'name' => $this->l('Extra right')),
				array(	'id' =>	9,
						'name' => $this->l('Product footer')),
				),
			'Carrito' => array(
				array(	'id' => 10,
						'name' => $this->l('Shopping cart')),
				array(	'id' =>	11,
						'name' => $this->l('Shopping cart extra')),
				),
			'Checkout' => array(
				array(	'id' => 12,
						'name' => $this->l('Payment Top')),
				),
		);

		$recommendersLang = array(
			'Home' => $this->l('Home Page'),
			'Producto' => $this->l('Product Page'),
			'Carrito' => $this->l('Cart Page'),
			'Checkout' => $this->l('Checkout Page'),
		);

		$hooksLocation = array();
		if (Configuration::get('BRAINSINS_HOOKS_LOCATIONS'))
		{
			foreach (explode('|', Configuration::get('BRAINSINS_HOOKS_LOCATIONS')) as $hook)
			{
				list($recommender_id, $hook_id, $custom_location, $page_type) = explode(':', $hook);

				$hooksLocation[$recommender_id]['location'] = $hook_id;
				$hooksLocation[$recommender_id]['custom_location'] = $custom_location;
				$hooksLocation[$recommender_id]['enabled'] = 1;
				$hooksLocation[$recommender_id]['page_type'] = $page_type;
			}
		}

		$this->context->smarty->assign(array(
			'enabled'			=> Configuration::get('BRAINSINS_ENABLED'),
			'debug'				=> Configuration::get('BRAINSINS_DEBUG'),
			'bskey'				=> Configuration::get('BRAINSINS_KEY'),
			'users_mail'		=> Configuration::get('BRAINSINS_USERS_MAIL'),
			'recommenders'		=> isset($recommenders) ? $recommenders : '',
			'recommendersLang'	=> $recommendersLang,
			'error'				=> (isset($error) && $error === true) ? 'true' : '',
			'availableHooks'	=> $hooks,
			'hooksLocation'		=> $hooksLocation,
			'feedUrl'			=> _PS_BASE_URL_.__PS_BASE_URI__.'modules/'.$this->name.'/feed.php',
			'this_path' 		=> $this->_path,
			'errors'			=> $this->_errors,
			'success'			=> $this->_success,
		));

		if (_PS_VERSION_ < '1.5')
		{
			echo '<link type="text/css" rel="stylesheet" href="'.$this->_path.'css/brainsins_admin.css" />';
			return $this->display(__FILE__, 'views/templates/hook/admin_form.tpl');
		}
		else
		{
			$this->context->controller->addCSS(($this->_path).'css/brainsins_admin.css', 'all');
			return $this->display(__FILE__, 'admin_form.tpl');
		}
	}

	public function hookFooter()
	{
		//Check if module is enabled && key is correct
		if (!$this->validateBSData())
			return;

		try {

			if (version_compare(_PS_VERSION_, '1.5', '<'))
				$page_name = isset($_SERVER['PHP_SELF']) ? Tools::substr($_SERVER['PHP_SELF'], Tools::strlen(__PS_BASE_URI__), -4) : '';
			else
				$page_name = Dispatcher::getInstance()->getController();

			$html = '';

			if ($page_name == 'index')
				$html .= $this->checkRecommendersByHook(4);
			elseif ($page_name == 'product')
				$html .= $this->checkRecommendersByHook(17);

			$html .= "
					<!-- BrainSINS Code Starts -->
					<script type='text/javascript'>
						var bs = document.createElement('script');
						bs.type = 'text/javascript';
						bs.async = true;
						bs.src = (document.location.protocol == 'https:' ? 'https://d2xkqxdy6ewr93.cloudfront.net' : 'http://clients.cdn.brainsins.com') + '/brainsins_v3.js' ;
						var head = document.getElementsByTagName('head')[0];
						head.appendChild(bs);
						brainsins_token = '".Configuration::get('BRAINSINS_KEY')."';
					";

			$lang = new Language((int)$this->context->cookie->id_lang);
			$currency = new Currency($this->context->cookie->id_currency);

			if (Validate::isModuleName(Tools::getValue('module')))
				$module_name = Tools::getValue('module');

			if ($page_name == 'index')
				$html .= $this->checkRecommendersByPage('Home');
			elseif ($page_name == 'product')
				$html .= $this->checkRecommendersByPage('Producto');

			elseif (Tools::strtolower($page_name) == 'order' && Tools::getValue('step') == 0)
				$html .= $this->checkRecommendersByPage('Carrito');
			elseif ((Tools::strtolower($page_name) == 'order' && Tools::getValue('step') != 0) ||
				(Tools::strtolower($page_name) == 'order-opc') || (Tools::strtolower($page_name) == 'orderopc') ||
				(isset($module_name) && $module_name == 'onepagecheckoutps' && $page_name == 'main'))
				$html .= $this->checkRecommendersByPage('Checkout');

			$html .= "
						var BrainSINSData = {
							language: '".$lang->iso_code."',
							currency: '".$currency->iso_code_num."',
						";

			if (Tools::strtolower($page_name) == 'index')
			{
				//Home
				$html .= "	pageType: 'home',
						";

			}

			if (Tools::strtolower($page_name) == 'product')
			{
				//Product Page
				//In the product page you need to include another tag, that will send us the information about the product being visited by the user
				$id_product = (int)Tools::getValue('id_product');
				$html .= "	pageType: 'product',
							productId: ".$id_product.",
						";
			}
			elseif (Tools::strtolower($page_name) == 'order' && Tools::getValue('step') == 0)
			{
				//Cart page
				//In the cart page you need to generate a code that sends to BrainSINS the cart contents,
				//including the product ids && the quantity for each product
				$cart = new Cart((int)$this->context->cookie->id_cart);

				$html .= "	pageType: 'cart',
						";
			}
			elseif ((Tools::strtolower($page_name) == 'order' && Tools::getValue('step') != 0) ||
				(Tools::strtolower($page_name) == 'order-opc') || (Tools::strtolower($page_name) == 'orderopc') ||
				(isset($module_name) && $module_name == 'onepagecheckoutps' && $page_name == 'main'))
			{
				//Checkout process
				//When the checkout process start because the user is ready to pay, you need to generate the following code:
				$html .= "	pageType: 'checkout',
						";
			}
			elseif (Tools::strtolower($page_name) == 'category')
			{
				//Category Page
				//When the checkout process start because the user is ready to pay, you need to generate the following code:
				$category = new Category((int)Tools::getValue('id_category'));
				$parent_list = array_reverse($category->getParentsCategories());

				//We only get the id_category
				$categories = array();
				foreach ($parent_list as $category)
					$categories[] = $category['id_category'];

				$html .= "	pageType: 'category',
							categories: '".implode(', ', $categories)."',
							categoryId: '".(int)Tools::getValue('id_category')."',
						";
			}

			if (isset($this->context->cookie->recommenders) && $this->context->cookie->recommenders != '')
			{

				$html .= "	recommenders: [";
				$html .= $this->context->cookie->recommenders."		]";

				$this->context->cookie->recommenders = '';
			}

			$html .= "
						};

						</script>
						<!-- BrainSINS Code Ends -->";

			//If logged but brainSINS cookie not logged
			if (((version_compare(_PS_VERSION_, '1.5', '<') && $this->context->cookie->isLogged())
				|| (version_compare(_PS_VERSION_, '1.5', '>') && $this->context->customer->isLogged()))
				&& ((!isset($_COOKIE['ul']) || $_COOKIE['ul'] == 0) || $this->context->cookie->justLogged == 1))
			{

				$lang = new Language((int)$this->context->cookie->id_lang);
				$cart = new Cart((int)$this->context->cookie->id_cart);
				$currency = new Currency($cart->id_currency);

				$users_mail = Configuration::get('BRAINSINS_USERS_MAIL');
				if (($users_mail == 1 && $this->context->customer->newsletter) || ($users_mail == 2))
					$userNewsletter = 1;
				else
					$userNewsletter = 0;

				$html .= "
						<!-- BrainSINS Code Login Starts -->
						<script type='text/javascript'>
							$(window).load(function() {
								BrainSINSTracker.trackEMailNewsletter('".$this->context->customer->email."', ".$userNewsletter.", '".$lang->iso_code."');
							});
						</script>
						<!-- BrainSINS Code Login Ends -->
					";

				$this->context->cookie->justLogged = 0;
			}

			//if not logged but brainSINS cookie logged
			if (((version_compare(_PS_VERSION_, '1.5', '<') && !$this->context->cookie->isLogged())
				|| (version_compare(_PS_VERSION_, '1.5', '>') && !$this->context->customer->isLogged()))
				&& isset($_COOKIE['ul']) && $_COOKIE['ul'] == 1)
			{
				$html .= "
						<!-- BrainSINS Code Logout Starts -->
						<script type='text/javascript'>
							$(window).load(function() {
								BrainSINSTracker.trackUserLoggedOut();
							});
						</script>
						<!-- BrainSINS Code Logout Ends -->
					";
			}

			return $html;

		} 
		catch (Exception $e)
		{
			$e->displayMessage();
			$this->context->cookie->recommenders = '';
		}
	}

	public function hookActionAuthentication()
	{
		//Check if module is enabled && key is correct
		if (!$this->validateBSData())
			return;

		$this->context->cookie->justLogged = 1;
	}

	public function hookTop()
	{
		if (version_compare(_PS_VERSION_, '1.5', '<'))
			$page_name = isset($_SERVER['PHP_SELF']) ? Tools::substr($_SERVER['PHP_SELF'], Tools::strlen(__PS_BASE_URI__), -4) : '';
		else
			$page_name = Dispatcher::getInstance()->getController();

		if ($page_name == 'index')
			return $this->checkRecommendersByHook(1);
		elseif ($page_name == 'product')
			return $this->checkRecommendersByHook(14);
	}

	public function hookLeftColumn()
	{
		if (version_compare(_PS_VERSION_, '1.5', '<'))
			$page_name = isset($_SERVER['PHP_SELF']) ? Tools::substr($_SERVER['PHP_SELF'], Tools::strlen(__PS_BASE_URI__), -4) : '';
		else
			$page_name = Dispatcher::getInstance()->getController();

		if ($page_name == 'index')
			return $this->checkRecommendersByHook(2);
		elseif ($page_name == 'product')
			return $this->checkRecommendersByHook(15);
	}

	public function hookRightColumn()
	{
		if (version_compare(_PS_VERSION_, '1.5', '<'))
			$page_name = isset($_SERVER['PHP_SELF']) ? Tools::substr($_SERVER['PHP_SELF'], Tools::strlen(__PS_BASE_URI__), -4) : '';
		else
			$page_name = Dispatcher::getInstance()->getController();

		if ($page_name == 'index')
			return $this->checkRecommendersByHook(3);
		elseif ($page_name == 'product')
			return $this->checkRecommendersByHook(16);
	}

	public function hookExtraLeft()
	{
		return $this->checkRecommendersByHook(5);
	}

	public function hookProductActions()
	{
		return $this->checkRecommendersByHook(6);
	}

	public function hookActionProductOutOfStock()
	{
		return $this->checkRecommendersByHook(7);
	}

	public function hookExtraRight()
	{
		return $this->checkRecommendersByHook(8);
	}

	public function hookProductFooter()
	{
		return $this->checkRecommendersByHook(9);
	}

	public function hookShoppingCart()
	{
		return $this->checkRecommendersByHook(10);
	}

	public function hookShoppingCartExtra()
	{
		return $this->checkRecommendersByHook(11);
	}

	public function hookPaymentTop()
	{
		return $this->checkRecommendersByHook(12);
	}

	public function hookOrderConfirmation($params)
	{
		//Check if module is enabled && key is correct
		if (!$this->validateBSData())
			return;

		if ($params['objOrder'] && !Validate::isLoadedObject($params['objOrder']))
			die($this->l('Incorrect Order object.'));

		$cart = new Cart((int)$params['objOrder']->id_cart);
		$currency = new Currency(Configuration::get('PS_CURRENCY_DEFAULT'));

		$ruta = 'purchase/close/';

		$url = $this->api_url.$ruta.(int)$params['objOrder']->id.'/'.$this->getUser().'/'.
			Tools::convertPrice($cart->getOrderTotal(true, Cart::BOTH_WITHOUT_SHIPPING), $currency->id).
			'.json?token='.Configuration::get('BRAINSINS_KEY');

		$this->WSCall($url);
	}

	public function hookPaymentConfirmation($params)
	{
		//Check if module is enabled && key is correct
		if (!$this->validateBSData())
			return;

		if ($params['objOrder'] && !Validate::isLoadedObject($params['objOrder']))
			die($this->l('Incorrect Order object.'));

		$ruta = 'purchase/payment.json?';

		$url = $this->api_url.$ruta.'token='.Configuration::get('BRAINSINS_KEY').'&idUser='.$this->getUser().'&idPurchase='.(int)$params['objOrder']->id;

		$this->WSCall($url);
	}

	public function hookCart($params)
	{
		//Check if module is enabled && key is correct
		if (!$this->validateBSData())
			return;

		if (($params['cart'] && !Validate::isLoadedObject($params['cart'])) || !isset($params['cart']->id))
			//Incorrect Order object
			return;

		$cart = new Cart($params['cart']->id);

		$ruta = 'order/trackOrder.xml?';

		$url = $this->api_url.$ruta.'token='.Configuration::get('BRAINSINS_KEY');

		$cartXML = new DOMDocument('1.0', 'UTF-8');
		$cartXML->xmlStandalone = true;

		$pRecsins = $cartXML->createElement('recsins');
		$pRecsins->setAttribute('version', '0.1');
		$cartXML->appendChild($pRecsins);

		$pOrders = $cartXML->createElement('orders');

		$pOrder = $cartXML->createElement('order');
		$pIdBuyer = $cartXML->createElement('idBuyer', $this->getUser());
		$pOrder->appendChild($pIdBuyer);

		$currency = new Currency((int)$params['cart']->id_currency);
		$pCurrency = $cartXML->createElement('idCurrency', $currency->iso_code);
		$pOrder->appendChild($pCurrency);

		$pOrders->appendChild($pOrder);

		$pRecsins->appendChild($pOrders);

		$pProducts = $cartXML->createElement('products');
		$pOrder->appendChild($pProducts);

		$products = $cart->getProducts();

		foreach ($products as $product)
		{
			$pProduct = $cartXML->createElement('product');

			$pIdProduct = $cartXML->createElement('idProduct', $product['id_product']);
			$pProduct->appendChild($pIdProduct);

			$pPrice = $cartXML->createElement('price', Product::getPriceStatic($product['id_product'], true, null, 2));
			$pProduct->appendChild($pPrice);

			$pQuantity = $cartXML->createElement('quantity', $product['cart_quantity']);
			$pProduct->appendChild($pQuantity);

			$pProducts->appendChild($pProduct);
		}

		$content = $cartXML->saveXML($cartXML->documentElement);
		$this->WSCall($url, $content);
	}

	public function validateBSData()
	{
		//Check if module is enabled
		if (!Configuration::get('BRAINSINS_ENABLED'))
			return false;

		//Validate if key is defined
		$key = Configuration::get('BRAINSINS_KEY');
		if (!isset($key) || $key == '' || !$this->checkBSKey($key))
			return false;
		else
			return true;
	}

	private function WSCall($url, $content = null)
	{
		if (function_exists('curl_init'))
		{
			$ch = curl_init($url);

			if (Configuration::get('BRAINSINS_DEBUG'))
				$logfh = fopen(dirname(__FILE__).'/log.log', 'a+');

			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/xml'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
			curl_setopt($ch, CURLOPT_VERBOSE, true);
			if (Configuration::get('BRAINSINS_DEBUG'))
			{
				curl_setopt($ch, CURLOPT_STDERR, $logfh);
				fwrite($logfh, $content);
			}

			$response = curl_exec($ch);
			curl_close($ch);

			if (Configuration::get('BRAINSINS_DEBUG'))
				fclose($logfh);
		}
		else
		{
			$opts = array('http' =>
						array(
							'method'  => 'POST',
							'header'  => 'Content-type: text/xml',
							'content' => $content
						)
			);

			$context  = stream_context_create($opts);

			$response = Tools::file_get_contents($url, false, $context);
		}

		return $response;
	}

	private function checkRecommendersByHook($hook_called)
	{
		if (!$this->validateBSData())
			return;

		$html = '';

		$hooks = Configuration::get('BRAINSINS_HOOKS_LOCATIONS');

		if ($hooks)
		{
			foreach (explode('|', $hooks) as $hook)
			{
				list($recommender_id, $hook_id, $custom_location) = explode(':', $hook);
				if ($hook_id == $hook_called && $custom_location == '')
				{
					$this->loadRecommender(1, $recommender_id);
					$html .= '<div id="brainSINS_recommender_'.$recommender_id.'"></div>';
				}
			}
		}

		return $html;
	}

	private function checkRecommendersByPage($page_name)
	{
		if (!$this->validateBSData())
			return;

		$html = '';

		$hooks = Configuration::get('BRAINSINS_HOOKS_LOCATIONS');

		if ($hooks)
		{
			foreach (explode('|', $hooks) as $hook)
			{
				list($recommender_id, $hook_id, $custom_location, $page_type) = explode(':', $hook);
				if ($page_type == $page_name && $hook_id == '' && $custom_location != '')
					$this->loadRecommender(2, $recommender_id, $custom_location);
			}
		}

		return $html;
	}

	private function loadRecommender($type, $recommender_id, $custom_location = null)
	{
		if ($type == 1)
		{
			$this->context->cookie->recommenders .= "
								{
									recommenderId: ".$recommender_id.",
									location: 'brainSINS_recommender_".$recommender_id."',
									position: 'replace'
								},
					";
		}
		else
		{
			$this->context->cookie->recommenders .= "
								{
									recommenderId: ".$recommender_id.",
									location: '".$custom_location."',
									position: 'replace'
								},
					";
		}
		return true;
	}

	private function getUser()
	{
		//brainSINS user is logged
		if (isset($_COOKIE['ul']) && $_COOKIE['ul'] == 1)
			return $_COOKIE['uId'];
		elseif (isset($_COOKIE['ul']) && $_COOKIE['ul'] == 0)
			return $_COOKIE['coId'];
		else
			return;
	}
}
