<?php
/*
* The MIT License (MIT)
*
* Copyright (c) 2014 Social Gaming Platform SRL
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*/

ini_set ('memory_limit', '512M');
ini_set('max_execution_time', '99999999');
ini_set('display_errors', '0');
error_reporting(1);

include(dirname(__FILE__).'/../../config/config.inc.php');
require_once(dirname(__FILE__).'/../../init.php');
header('Content-Type:application/xml');

/* Backward compatibility */
if (version_compare(_PS_VERSION_, '1.5', '<'))
	require(_PS_MODULE_DIR_.'brainsins/backward_compatibility/backward.php');

//Creación objeto y cabecera rss Google
$p_dom_brain = new DOMDocument('1.0', 'UTF-8');
$p_dom_brain->formatOutput = true;
$p_dom_brain->xmlStandalone = true;

$p_recsins = $p_dom_brain->createElement('recsins');
$p_recsins->setAttribute('version', '0.1');
$p_dom_brain->appendChild($p_recsins);

$p_entities = $p_dom_brain->createElement('entities');
$p_recsins->appendChild($p_entities);

$rows = 0;

//Cargamos todos los productos en un array
if (_PS_VERSION_ < '1.5')
{
	$languages = Language::getLanguages(true);
	$currencies = Currency::getCurrencies();
	$products = Product::getProducts((int)Context::getContext()->cookie->id_lang, 0, null, 'id_product', 'asc', false, true);
}
else
{
	$languages = Language::getLanguages(true, (int)Context::getContext()->shop->id);
	$currencies = Currency::getCurrenciesByIdShop((int)Context::getContext()->shop->id);
	$products = Product::getProducts((int)Context::getContext()->language->id, 0, null, 'id_product', 'asc', false, true);
}

$products_lang = $products;


foreach ($products_lang as $key => $product)
{
	$p_entity = $p_dom_brain->createElement('entity');
	$p_entity->setAttribute('name', 'product');
	$p_entities->appendChild($p_entity);

	$p_idprod = $p_dom_brain->createElement('property');
	$p_idprod->setAttribute('name', 'idProduct');
	$cdata = $p_dom_brain->createTextNode($product['id_product']);
	$p_idprod->appendChild($cdata);
	$p_entity->appendChild($p_idprod);

	$p_mpname = $p_dom_brain->createElement('multi_property');
	$p_mpname->setAttribute('name', 'name');

	$p_mpdesc = $p_dom_brain->createElement('multi_property');
	$p_mpdesc->setAttribute('name', 'description');

	$p_mpurl = $p_dom_brain->createElement('multi_property');
	$p_mpurl->setAttribute('name', 'url');

	foreach ($languages as $language)
	{
		$product_lang = getLang($product['id_product'], $language['id_lang']);
		$p_lang_name = $p_dom_brain->createElement('property');
		$p_lang_name->setAttribute('lang', $language['iso_code']);
		$cdata = $p_dom_brain->createCDATASection($product_lang['name']);
		$p_lang_name->appendChild($cdata);
		$p_mpname->appendChild($p_lang_name);

		$p_lang_desc = $p_dom_brain->createElement('property');
		$p_lang_desc->setAttribute('lang', $language['iso_code']);
		$cdata = $p_dom_brain->createCDATASection($product_lang['description']);
		$p_lang_desc->appendChild($cdata);
		$p_mpdesc->appendChild($p_lang_desc);

		$p_lang_link = $p_dom_brain->createElement('property');
		$p_lang_link->setAttribute('lang', $language['iso_code']);
		$product_link = Context::getContext()->link->getProductLink($product['id_product'], $product_lang['link_rewrite']);
		$cdata = $p_dom_brain->createCDATASection($product_link);
		$p_lang_link->appendChild($cdata);
		$p_mpurl->appendChild($p_lang_link);
	}

	$p_entity->appendChild($p_mpname);

	$p_entity->appendChild($p_mpdesc);

	$p_entity->appendChild($p_mpurl);

	$p_price = $p_dom_brain->createElement('property');
	$p_price->setAttribute('name', 'price');
	$product_price = Product::getPriceStatic($product['id_product'], true, null, 2);
	$cdata = $p_dom_brain->createTextNode($product_price);
	$p_price->appendChild($cdata);
	$p_entity->appendChild($p_price);


	$p_mpcur = $p_dom_brain->createElement('multi_property');
	$p_mpcur->setAttribute('name', 'multiprice');

	//Multicurrency
	foreach ($currencies as $curr)
	{
		$p_price = $p_dom_brain->createElement('property');
		$p_price->setAttribute('currency', $curr['iso_code_num']);
		$price_converted = Tools::ps_round(Tools::convertPrice($product_price, $curr['id_currency']), 2);
		$cdata = $p_dom_brain->createTextNode($price_converted);
		$p_price->appendChild($cdata);
		$p_mpcur->appendChild($p_price);
	}
	$p_entity->appendChild($p_mpcur);


	$image = Image::getImages((int)Context::getContext()->cookie->id_lang, $product['id_product']);

	$p_image = $p_dom_brain->createElement('property');
	$p_image->setAttribute('name', 'imageUrl');
	if (is_array($image) && count($image))
	{
		if (_PS_VERSION_ < '1.5')
			$image_size = 'large';
		else
			$image_size = 'large_default';

		$image_url = Context::getContext()->link->getImageLink($product['link_rewrite'],
			(int)$product['id_product'].'-'.(int)$image[0]['id_image'], $image_size);
		$cdata = $p_dom_brain->createCDATASection($image_url);
		$p_image->appendChild($cdata);
	}
	$p_entity->appendChild($p_image);

	$p_category = $p_dom_brain->createElement('property');
	$p_category->setAttribute('name', 'categories');
	$cdata = $p_dom_brain->createTextNode(implode(',', Product::getProductCategories((int)$product['id_product'])));
	$p_category->appendChild($cdata);
	$p_entity->appendChild($p_category);

	$rows++;
	$image = null;
	unset($image);

	$image_obj = null;
	unset($image_obj);

	//Quitamos el producto procesado del array de productos para liberar memoria.
	$products[$key] = null;
	unset($products[$key]);
}

$products = null;
unset($products);

echo $p_dom_brain->saveXML();
//$p_dom_brain->save('php://output');

unset($p_dom_brain);

function getLang($id_product, $language)
{
	if (_PS_VERSION_ < '1.5')
	{
		$sql = 'SELECT pl.*
		FROM `'._DB_PREFIX_.'product` p
		LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (p.`id_product` = pl.`id_product`)
		WHERE pl.`id_product` = '.(int)$id_product.'
		AND pl.`id_lang` = '.(int)$language;
	}
	else
	{
		$sql = 'SELECT pl.*
		FROM `'._DB_PREFIX_.'product` p
		'.Shop::addSqlAssociation('product', 'p').'
		LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (p.`id_product` = pl.`id_product`)
		WHERE pl.`id_product` = '.(int)$id_product.'
		AND pl.`id_lang` = '.(int)$language;
	}

	$rq = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow($sql);

	return ($rq);
}