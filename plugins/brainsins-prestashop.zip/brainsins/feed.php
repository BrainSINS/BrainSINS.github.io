<?php

ini_set('memory_limit','512M');
ini_set('max_execution_time','99999999');
ini_set('display_errors', '0');
error_reporting(1);

include(dirname(__FILE__).'/../../config/config.inc.php');
require_once(dirname(__FILE__).'/../../init.php');
header('Content-Type:application/xml');


//Creación objeto y cabecera rss Google
$pDomBrain = new DOMDocument('1.0','UTF-8');
$pDomBrain->formatOutput = true;
$pDomBrain->xmlStandalone = true;

$pRecsins = $pDomBrain->createElement('recsins');
$pRecsins->setAttribute('version', '0.1');
$pDomBrain->appendChild($pRecsins);

$pEntities = $pDomBrain->createElement('entities');
$pRecsins->appendChild($pEntities);

$rows = 0;

//Cargamos todos los productos en un array
if (_PS_VERSION_ < '1.5') {
	$languages = Language::getLanguages(true);
	$currencies = Currency::getCurrencies();
	$products = Product::getProducts((int)$cookie->id_lang, 0, null, 'id_product', 'asc', false, true);
}
else {
	$languages = Language::getLanguages(true, (int)Context::getContext()->shop->id);
	$currencies = Currency::getCurrenciesByIdShop((int)Context::getContext()->shop->id);
	$products = Product::getProducts((int)Context::getContext()->language->id, 0, null, 'id_product', 'asc', false, true);
}

$productsLang = $products;


foreach ($productsLang as $key => $product)
{
	$pEntity = $pDomBrain->createElement('entity');
	$pEntity->setAttribute('name', 'product');
	$pEntities->appendChild($pEntity);

	$pIDProd = $pDomBrain->createElement('property');
	$pIDProd->setAttribute('name', 'idProduct');
	$cdata = $pDomBrain->createTextNode($product['id_product']);
	$pIDProd->appendChild($cdata);
	$pEntity->appendChild($pIDProd);

	$pMPName = $pDomBrain->createElement('multi_property');
	$pMPName->setAttribute('name', 'name');

	$pMPDesc = $pDomBrain->createElement('multi_property');
	$pMPDesc->setAttribute('name', 'description');

	$pMPUrl = $pDomBrain->createElement('multi_property');
	$pMPUrl->setAttribute('name', 'url');

	foreach ($languages as $language) {
		$product_lang = getLang($product['id_product'], $language['id_lang']);
		$pLangName = $pDomBrain->createElement('property');
		$pLangName->setAttribute('lang', $language['iso_code']);
		$cdata = $pDomBrain->createCDATASection($product_lang['name']);
		$pLangName->appendChild($cdata);
		$pMPName->appendChild($pLangName);

		$pLangDesc = $pDomBrain->createElement('property');
		$pLangDesc->setAttribute('lang', $language['iso_code']);
		$cdata = $pDomBrain->createCDATASection($product_lang['description']);
		$pLangDesc->appendChild($cdata);
		$pMPDesc->appendChild($pLangDesc);

		$pLangLink = $pDomBrain->createElement('property');
		$pLangLink->setAttribute('lang', $language['iso_code']);
		$product_link = $link->getProductLink($product['id_product'], $product_lang['link_rewrite']);
		$cdata = $pDomBrain->createCDATASection($product_link);
		$pLangLink->appendChild($cdata);
		$pMPUrl->appendChild($pLangLink);
	}

	$pEntity->appendChild($pMPName);

	$pEntity->appendChild($pMPDesc);

	$pEntity->appendChild($pMPUrl);

	$pPrice = $pDomBrain->createElement('property');
	$pPrice->setAttribute('name', 'price');
	$product_price = Product::getPriceStatic($product['id_product'], true, null, 2);
	$cdata = $pDomBrain->createTextNode($product_price);
	$pPrice->appendChild($cdata);
	$pEntity->appendChild($pPrice);


	$pMPCur = $pDomBrain->createElement('multi_property');
	$pMPCur->setAttribute('name', 'multiprice');

	//Multicurrency
	foreach ($currencies as $curr){
		$pPrice = $pDomBrain->createElement('property');
		$pPrice->setAttribute('currency', $curr['iso_code_num']);
		$price_converted = Tools::ps_round(Tools::convertPrice($product_price, $curr['id_currency']), 2);
		$cdata = $pDomBrain->createTextNode($price_converted);
		$pPrice->appendChild($cdata);
		$pMPCur->appendChild($pPrice);
	}
	$pEntity->appendChild($pMPCur);


	$image = Image::getImages((int)($cookie->id_lang), $product['id_product']);

	$pImage = $pDomBrain->createElement('property');
	$pImage->setAttribute('name', 'imageUrl');
	if (is_array($image) AND sizeof($image))
	{
		if (_PS_VERSION_ < '1.5')
			$image_size = 'large';
		else
			$image_size = 'large_default';

		$imageUrl = $link->getImageLink($product['link_rewrite'], (int)$product['id_product'].'-'.(int)$image[0]['id_image'], $image_size);
		$cdata = $pDomBrain->createCDATASection($imageUrl);
		$pImage->appendChild($cdata);
	}
	$pEntity->appendChild($pImage);

	$pCategory = $pDomBrain->createElement('property');
	$pCategory->setAttribute('name', 'categories');
	$cdata = $pDomBrain->createTextNode(implode(",", Product::getProductCategories((int)$product['id_product'])));
	$pCategory->appendChild($cdata);
	$pEntity->appendChild($pCategory);

	$rows++;
	$image = null;
	unset($image);

	$imageObj = null;
	unset($imageObj);

	//Quitamos el producto procesado del array de productos para liberar memoria.
	$products[$key]= null;
	unset($products[$key]);
}

$products = null;
unset($products);

echo $pDomBrain->saveXML();
//$pDomBrain->save('php://output');

unset($pDomBrain);

function getLang($id_product, $language)
{
	if (_PS_VERSION_ < '1.5') {
		$sql = 'SELECT pl.*
		FROM `'._DB_PREFIX_.'product` p
		LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (p.`id_product` = pl.`id_product`)
		WHERE pl.`id_product` = '.(int)$id_product.'
		AND pl.`id_lang` = '.(int)$language;
	}
	else {
		$sql = 'SELECT pl.*
		FROM `'._DB_PREFIX_.'product` p
		'.Shop::addSqlAssociation('product', 'p').'
		LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (p.`id_product` = pl.`id_product`)
		WHERE pl.`id_product` = '.(int)$id_product.'
		AND pl.`id_lang` = '.(int)$language;
	}

	$rq = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow($sql);

	return ($rq);
}