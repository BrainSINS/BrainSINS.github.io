<?php
/*
* The MIT License (MIT)
*
* Copyright (c) 2014 Social Gaming Platform SRL
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*/

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');

/* Backward compatibility */
if (version_compare(_PS_VERSION_, '1.5', '<'))
	require(_PS_MODULE_DIR_.'brainsins/backward_compatibility/backward.php');

if (Tools::getValue('p') && Tools::getValue('q'))
{
	//Version compare
	if (_PS_VERSION_ < '1.5')
	{
		_setCart();
		Tools::redirect('order.php');
	}
	else
	{
		$params = array();
		$params['p'] = Tools::getValue('p');
		$params['q'] = Tools::getValue('q');
		Tools::redirect(Context::getContext()->link->getModuleLink('brainsins', 'cart', $params));
	}
}
else
{
	header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");
	header("Location: ../");
	exit;
}

function _setCart()
{
	$products = explode(',', Tools::getValue('p'));
	$qties = explode(',', Tools::getValue('q'));

	//New cart
	if (!Context::getContext()->cart->id)
	{
		if (Context::getContext()->cookie->id_guest)
		{
			$guest = new Guest(Context::getContext()->cookie->id_guest);
			Context::getContext()->cart->mobile_theme = $guest->mobile_theme;
		}
		Context::getContext()->cart->add();
		if (Context::getContext()->cart->id)
			Context::getContext()->cookie->id_cart = (int)Context::getContext()->cart->id;
	}

	$existing_cart = new Cart(Context::getContext()->cookie->id_cart);
	$existing_products = $existing_cart->getProducts();

	//Add products and quantities
	foreach ($products as $key => $id_product)
	{
		if (!_checkIfProductExists($id_product))
			continue;
		if (_checkIfProductExistsInCart($id_product, $existing_products))
			continue;
		if ((int)$qties[$key])
			$qty = (int)$qties[$key];
		else
			$qty = 1;
		$ipa_default = (int)Product::getDefaultAttribute($id_product);
		Context::getContext()->cart->updateQty($qty, (int)$id_product, $ipa_default, false, 'up');
	}
}

function _checkIfProductExistsInCart($id_product, $products)
{
	foreach ($products as $product)
	{
		if ($product['id_product'] == $id_product)
			return true;
	}
	return false;
}

function _checkIfProductExists($id_product)
{
	$product = new Product($id_product);
	if ($product->id != null)
		return true;
	return false;
}
