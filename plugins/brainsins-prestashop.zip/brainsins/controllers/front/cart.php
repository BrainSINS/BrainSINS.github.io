<?php

class BrainsinsCartModuleFrontController extends ModuleFrontController
{
	public function __construct()
	{
		parent::__construct();

		$this->context = Context::getContext();
	}

	public function initContent()
	{
		parent::initContent();

		if(Tools::getValue('p') && Tools::getValue('q'))
		{
			//Get values
			$products = explode(',', Tools::getValue('p'));
			$qties = explode(',', Tools::getValue('q'));

			//Set cart
			$this->_setCart($products, $qties);

			//Redirect to the order controller
			Tools::redirect($this->context->link->getPageLink('order'));
		}
	}

	protected function _setCart($products, $qties)
	{
		//New cart
		if(!$this->context->cart->id)
		{
			if (Context::getContext()->cookie->id_guest)
			{
				$guest = new Guest(Context::getContext()->cookie->id_guest);
				$this->context->cart->mobile_theme = $guest->mobile_theme;
			}
			$this->context->cart->add();
			if ($this->context->cart->id)
				$this->context->cookie->id_cart = (int)$this->context->cart->id;
		}

		$existing_cart = new Cart($this->context->cart->id);
		$existing_products = $existing_cart->getProducts();

		//Add products and quantities
		foreach($products as $key => $id_product)
		{
			if(!$this->_checkIfProductExists($id_product))
				continue;
			if($this->_checkIfProductExistsInCart($id_product, $existing_products))
				continue;
			if(intval($qties[$key]))
				$qty = (int)$qties[$key];
			else
				$qty = 1;
			$ipa_default = (int)Product::getDefaultAttribute($id_product);
			$this->context->cart->updateQty($qty, (int)$id_product, $ipa_default, false, 'up', 0, null, true);
		}
		return;
	}
	
	protected function _checkIfProductExistsInCart($id_product, $products)
	{
		foreach ($products as $product)
		{
			if($product['id_product'] == $id_product)
				return true;
		}
		return false;
	}
	
	protected function _checkIfProductExists($id_product)
	{
		$product = new Product($id_product);
		if($product->id != null)
			return true;
		return false;
	}
}
